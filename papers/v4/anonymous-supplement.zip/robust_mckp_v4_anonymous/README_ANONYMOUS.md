# Anonymous v4 review supplement

This identity-scanned archive contains the implementation, tests, serialized
protocol, raw result records, environment records, generated numerical paper
inputs, vector figure, and blind manuscript PDFs.

Create an environment and verify the released evidence with:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-anonymous.txt
PYTHONPATH=src python -m pytest -q
PYTHONPATH=src python scripts/verify_v4_release.py   --results results/release   --paper papers/v4
```

The archive-specific evidence manifest excludes only public package metadata
that would identify the author. Its remaining source hashes and all evidence
hashes are verified by the command above. Raw UCI transactions are not
redistributed; the released aggregate calibration is included.
